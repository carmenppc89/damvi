package alumnes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

import estructura.Alumne;

// NO siguies mandr�s i canvia el nom al projecte amb el teu nom i cognom  

public class Programa {

	static final String csvAlumnes = "src\\data\\alumnes21.csv";
	static final String grup4F = "src\\data\\alumnes4F.csv";
	static final String grup4A = "src\\data\\alumnes4A.csv";
	static final String objAlumnes = "src\\data\\alumnes21.dat";
	static Scanner sc = new Scanner(System.in);
	
	static ArrayList<Alumne> alumnes = new ArrayList<Alumne>(); // disculpeu les est�tiques !!! �s per guanyar temps i
																// no haver de passar par�metres

	public static void main(String[] args) {
		
		int opcio = 1;
		while (opcio!=0) {
			opcio = menu();
			switch (opcio) {
			case 1:		//mostrar per pantalla el fitxer csv que li diguis		//TEXT    (0.75 p)
			case 2:		//carregar a l'array list d'alumnes el fitxer csv que li diguis		//TEXT		(1 p)
			case 3:		//mostrar la llista d'alumnes per pantalla			//No fitxers		(0.25 p)
			case 4:		//gravar l'alumnat del grup X del fitxer alumnes21.csv al fitxer alumnesXF.csv		//TEXT		(1p)
			case 5:		//gravar l'alumnat del grup X de la llista d'alumnes al fitxer alumnesXA.csv		//TEXT		(1p)
			case 6:		//afegir alumne	... instancia un nou alumne i l'afegeix al fitxer csv que diguis	//TEXT		(1p)
			case 7:		//netejar fitxer   //TEXT (0.5p)
				//............. FINS AQUI TEXT ...................
			case 8: 	//gravar alumnes serialitzats  ... agafa arraylist i el fica en fitxer serialitzat	(1.25)
			case 9:		alumnes.clear();
						//llegir fitxer serialitzat i carregar-ho a l'array list		(1.25)
			case 10:	//afegir alumne al fitxer serialitzat		(1p)
			case 11:	//esborrar alumnes d'un grup del fitxer serialitzat (1p)
			default:	System.err.println("Opci� triada: " + opcio + " ... t'has deixat els breaks?. No hauria d'haver arribat aqu� :(  ");
			}
			System.out.println("Bye, Institut");
		}
	}

	public static int menu() {
		System.out.println("\n******************************************\n");
		System.out.println("1.- Mostrar fitxer csv per pantalla                                                             0.75");
		System.out.println("2.- Carregar fitxer csv per pantalla                                                            1.00");
		System.out.println("3.- Mostrar Llista d'alumnes carregada per pantalla                                             0.25");
		System.out.println("4.- Demanar un grup i i partint del fitxer gravar en fitxer csv els alumnes del grup triat      1.00");
		System.out.println("5.- Demanar un grup i partint de l'arraylist gravar en fitxer csv els alumnes del grup triat    1.00");
		System.out.println("6.- Instanciar alumne i afegir-ho al fitxer csv que li diguis                                   1.00");
		System.out.println("7.- Netejar fitxer csv (deixar-ho buit                                                          0.50");
		System.out.println("8.- Gravar Alumnes Serialitzats (a partir de l'arraylist)                                       1.25");
		System.out.println("9.- Llegir el fitxer serialitzat i carregar-ho a l'arraylist                                    1.25");
		System.out.println("10- Instanciar alumne i afegir-ho al fitxer serialitzat                                         1.00");
		System.out.println("11- Triar un grup i esborrar els alumnes d'un grup del fitxer serialitzat                       1.00");
		
		return (sc.nextInt());
	}
}