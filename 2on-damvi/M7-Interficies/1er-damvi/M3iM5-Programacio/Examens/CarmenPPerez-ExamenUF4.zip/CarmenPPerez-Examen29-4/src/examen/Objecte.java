package examen;


public abstract class Objecte {

	protected boolean prioritari;
	protected TipusObjecte tipusObjecte;
	
	public Objecte(){
		prioritari=false;
	}
	
	public void llencar() {
		System.out.println("M'han llençat");
	}
	
}
