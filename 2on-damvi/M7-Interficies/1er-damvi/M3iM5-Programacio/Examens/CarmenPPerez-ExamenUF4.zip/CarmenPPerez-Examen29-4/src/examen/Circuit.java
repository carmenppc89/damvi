package examen;

import java.util.Random;

public class Circuit {

	public Objecte[] caselles;
	Random random;

	Circuit(int nObjectes) {
		caselles = new Objecte[50];
		for (int i = 0; i < caselles.length; i++) {
			caselles[i] = null;
		}

		if (nObjectes > 20) {
			nObjectes = 20;
		}
		int c;
		int t;
		for (int i = 0; i < nObjectes; i++) {
			c = (random.nextInt(49));

			if (caselles[c] == null) {
				t = random.nextInt(2);

				switch (t) {
				case 0:
					caselles[c] = Moneda.Moneda(c);
					break;
				case 1:
					caselles[c] = Platan.Platan();
					break;
				case 2:
					caselles[c] = Neumatic.Neumatic();
					break;

				default:
					break;
				}
			}
		}

	}
	
	public void visualitzar() {
		for (int i = 0; i < caselles.length; i++) {
			System.out.print(i+". ");
			if(caselles[i]instanceof Moneda) {
				System.out.println("M");
			}
			if(caselles[i]instanceof Platan) {
				System.out.println("P");
			}
			if(caselles[i]instanceof Neumatic) {
				System.out.println("N");
			}
		}

	}

}
