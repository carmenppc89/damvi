package examen;

public enum TipusObjecte {
	ATAC, DEFENSA, PREMI
}
