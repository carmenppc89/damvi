package examen;

public class Moneda extends Objecte {

	public int valor;
	public TipusObjecte tipusObjecte;

	Moneda(int quinvalor) {
		Objecte moneda = new Objecte();
		this.valor = quinvalor;
		this.prioritari = true;
		this.TipusObjecte = PREMI;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

}
