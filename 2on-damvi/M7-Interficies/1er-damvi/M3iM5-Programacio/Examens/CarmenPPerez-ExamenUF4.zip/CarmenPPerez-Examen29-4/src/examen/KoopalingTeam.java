package examen;

public class KoopalingTeam extends Pilot {

	KoopalingTeam(String nom) {
		super(nom);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void agafarObjecte(Objecte ob) {
		if (this.elMeuObjecte == null) {
			this.elMeuObjecte = ob;
		} else {
			if (ob instanceof Neumatic && this.elMeuObjecte instanceof Neumatic) {

				if (ob instanceof superNeumatic && ob.superNeumatic == true
						&& this.elMeuObjecte instanceof superNeumatic && (superNeumatic == false)) {
					this.elMeuObjecte = null;
					this.elMeuObjecte = ob;
				}

			}
		}

	}

	@Override
	public String cridar() {
		System.out.println("SIIIIIIIIII");
		return null;
	}

}
