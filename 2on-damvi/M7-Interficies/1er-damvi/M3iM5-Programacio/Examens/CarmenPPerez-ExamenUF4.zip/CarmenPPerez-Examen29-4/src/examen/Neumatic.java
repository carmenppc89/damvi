package examen;

import java.util.Random;

class Neumatic extends Objecte{
	
	public boolean superNeumatic;
	Random random;
	public TipusObjecte tipusObjecte;
	
	Neumatic(){
		Objecte neumatic = new Objecte();
		if((random.nextInt(1)) == 1)
			superNeumatic=true;
		else
			superNeumatic=false;
		
		this.TipusObjecte = DEFENSA;
		this.prioritari = false;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

}
