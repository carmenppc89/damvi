package examen;

public class MarioTeam extends Pilot {

	MarioTeam(String nom) {
		super(nom);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void agafarObjecte(Objecte ob) {
		if (this.elMeuObjecte == null) {
			this.elMeuObjecte = ob;
		} else {
			if (ob.prioritari == true && this.elMeuObjecte.prioritari == false) {
				this.elMeuObjecte = null;
				this.elMeuObjecte = ob;
			}
			if (this.elMeuObjecte instanceof Moneda && ob instanceof Moneda) {
				this.elMeuObjecte.valor += ob.valor;
			}
			if (this.elMeuObjecte instanceof Moneda && ob instanceof Moneda) {
				this.elMeuObjecte = null;
				this.elMeuObjecte = ob;
			}

		}

	}

	@Override
	public String cridar() {
		System.out.println("IUUUUUJUUUUU");
		return null;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

}
