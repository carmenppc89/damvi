package examen;

public abstract class Pilot {

	public String nom;
	public int posicio;
	public Objecte elMeuObjecte;
	
	Pilot(String nom){
		this.nom=nom;
		this.posicio=0;
		this.elMeuObjecte=null;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
	public abstract void agafarObjecte(Objecte ob);
	public abstract String cridar();
	
	public boolean avansar(Circuit c, int increment) {
		if((this.posicio+increment)>=50) {
			cridar();
			return false;
		}else {
			this.posicio=+increment;
			if(Circuit.caselles[this.posicio] instanceof Objecte) {
				agafarObjecte(Objecte);
				if(Objecte instanceof Moneda) {
					Circuit.caselles[this.posicio]=null;
					return true;
				}
			}
		}
		
	}
}
