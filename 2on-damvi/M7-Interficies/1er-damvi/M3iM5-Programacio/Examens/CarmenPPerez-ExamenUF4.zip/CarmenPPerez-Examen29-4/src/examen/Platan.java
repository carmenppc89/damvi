package examen;

class Platan extends Objecte {

	static int totalPlatans = 0;
	public int numPlatan = totalPlatans;
	public TipusObjecte tipusObjecte;

	Platan() {
		Objecte platan = new Objecte();
		this.totalPlatans++;
		this.numPlatan = this.totalPlatans;
		this.TipusObjecte = ATAC;
		this.prioritari = true;
	}
	
	@Override
	public void llencar() {
		System.out.println("Toma platanaco");
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

}
