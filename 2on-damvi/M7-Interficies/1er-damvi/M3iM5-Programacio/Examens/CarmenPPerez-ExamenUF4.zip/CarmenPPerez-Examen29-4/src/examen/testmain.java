package examen;

public class testmain {

	public static void main(String[] args) {

		Circuit circuit1 = new Circuit(20);
		circuit1.visualitzar();

		MarioTeam mario = new MarioTeam("mario");
		mario.avansar(circuit1, 1);
		
		KoopalingTeam koopa = new KoopalingTeam("koopa");
		koopa.avansar(circuit1, 1);

	}

}
