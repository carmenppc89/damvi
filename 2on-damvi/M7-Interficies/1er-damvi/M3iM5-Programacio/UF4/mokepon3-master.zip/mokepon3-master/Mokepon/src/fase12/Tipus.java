package fase12;

public enum Tipus {
	FOC, AIGUA, PLANTA;
}
