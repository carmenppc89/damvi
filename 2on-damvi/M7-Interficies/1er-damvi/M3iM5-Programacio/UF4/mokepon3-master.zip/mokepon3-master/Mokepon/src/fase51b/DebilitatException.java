package fase51b;

public class DebilitatException extends Exception{
	public DebilitatException(String message) {
		super(message);
	}
}
