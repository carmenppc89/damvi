package fase51b;

public class TipusDiferentException extends Exception{
	public TipusDiferentException(String message) {
		super(message);
	}
}
