package fase21;

public enum Tipus {
	FOC, AIGUA, PLANTA;
}
