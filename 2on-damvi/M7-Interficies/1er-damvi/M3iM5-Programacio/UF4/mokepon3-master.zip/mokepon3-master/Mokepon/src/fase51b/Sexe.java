package fase51b;

public enum Sexe {
MASCULI, FEMENI
}
