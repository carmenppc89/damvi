package fase41;

public enum Tipus {
	FOC, AIGUA, PLANTA;
}
