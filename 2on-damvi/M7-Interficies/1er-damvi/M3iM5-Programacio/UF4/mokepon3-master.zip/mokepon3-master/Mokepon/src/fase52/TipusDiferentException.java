package fase52;

public class TipusDiferentException extends Exception{
	public TipusDiferentException(String message) {
		super(message);
	}
}
