package fase6_Singleton;

public class SexeIgualException extends Exception{
	public SexeIgualException(String message) {
		super(message);
	}
}
