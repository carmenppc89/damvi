package fase52;

public class SexeIgualException extends Exception{
	public SexeIgualException(String message) {
		super(message);
	}
}
