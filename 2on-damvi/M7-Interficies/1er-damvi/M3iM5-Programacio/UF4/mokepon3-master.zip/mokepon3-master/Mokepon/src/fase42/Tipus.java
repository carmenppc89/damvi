package fase42;

public enum Tipus {
	FOC, AIGUA, PLANTA;
}
