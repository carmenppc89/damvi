package fase51b;

public enum Tipus {
	FOC, AIGUA, PLANTA;
}
