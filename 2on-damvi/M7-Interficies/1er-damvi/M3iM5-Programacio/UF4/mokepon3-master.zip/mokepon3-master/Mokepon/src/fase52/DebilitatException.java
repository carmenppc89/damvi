package fase52;

public class DebilitatException extends Exception{
	public DebilitatException(String message) {
		super(message);
	}
}
