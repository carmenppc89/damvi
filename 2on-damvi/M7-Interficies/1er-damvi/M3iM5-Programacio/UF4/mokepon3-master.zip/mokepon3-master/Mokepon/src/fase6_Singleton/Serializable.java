package fase6_Singleton;

public class Serializable {

}
