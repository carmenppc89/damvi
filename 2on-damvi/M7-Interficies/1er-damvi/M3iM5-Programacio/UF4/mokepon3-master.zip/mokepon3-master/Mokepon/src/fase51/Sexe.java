package fase51;

public enum Sexe {
MASCULI, FEMENI
}
