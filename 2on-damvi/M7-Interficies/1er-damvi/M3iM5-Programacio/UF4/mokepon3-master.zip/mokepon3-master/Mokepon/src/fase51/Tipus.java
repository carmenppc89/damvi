package fase51;

public enum Tipus {
	FOC, AIGUA, PLANTA;
}
