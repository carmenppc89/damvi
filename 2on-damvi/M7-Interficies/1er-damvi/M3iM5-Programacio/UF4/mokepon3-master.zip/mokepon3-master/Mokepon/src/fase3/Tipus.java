package fase3;

public enum Tipus {
	FOC, AIGUA, PLANTA;
}
