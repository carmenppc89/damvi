package fase52;

public enum Tipus{
	FOC, AIGUA, PLANTA;
}
