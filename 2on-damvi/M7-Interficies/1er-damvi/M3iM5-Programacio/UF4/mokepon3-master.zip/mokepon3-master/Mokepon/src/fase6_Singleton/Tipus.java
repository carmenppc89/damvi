package fase6_Singleton;

import java.io.Serializable;

public enum Tipus implements Serializable{
	FOC, AIGUA, PLANTA;
}
