package fase13;

public enum Tipus {
	FOC, AIGUA, PLANTA;
}
