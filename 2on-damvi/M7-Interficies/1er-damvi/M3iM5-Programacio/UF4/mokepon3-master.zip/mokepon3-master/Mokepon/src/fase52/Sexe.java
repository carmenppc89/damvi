package fase52;

public enum Sexe {
MASCULI, FEMENI
}
