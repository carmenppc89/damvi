package fase14;

public enum Tipus {
	FOC, AIGUA, PLANTA;
}
