package fase6_Singleton;

public enum Sexe {
MASCULI, FEMENI
}
