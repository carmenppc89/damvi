package cosaspasadas;

import java.util.Scanner;

public class buceador {
	static Scanner sc = new Scanner(System.in);

	// static int bajar = 100;
	static int aclimatarse = 10;
	static int total = 0;
	// static int contador = 0;
	static int acumulador = 0;
	static int profundidad = sc.nextInt();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int contador = 0;
		// int acumulador = 0;

		// checkeoprofundidad();
		while (profundidad < 300) {
			System.out.println("El valor ha de ser 300 com a minim");
			profundidad = sc.nextInt();
		}

		contador = NumeroVueltas(contador);
		// int cosa = contador;
		acumulador = ContarMinutos(contador);
		int resultat = acumulador;
		System.out.println(resultat);

	}

	public static void checkeoprofundidad() {

		while (profundidad < 300) {
			System.out.println("El valor ha de ser 300 com a minim");
			profundidad = sc.nextInt();
		}

	}

	public static int NumeroVueltas(int contador) {
		int bajar = 100;
		while (profundidad > 0) {
			total = total + bajar;
			profundidad = profundidad - bajar;
			contador++;
		}
		return contador;
	}

	// añade el acumulador en alguna lado
	public static int ContarMinutos(int contador) {// aqui acumulador
		//o aqui
		// cosa = contador;
		for (int i = 0; i < contador; i++) {

			acumulador = acumulador + 15;
		}
		acumulador = acumulador - 10;

		return acumulador;

	}

}
