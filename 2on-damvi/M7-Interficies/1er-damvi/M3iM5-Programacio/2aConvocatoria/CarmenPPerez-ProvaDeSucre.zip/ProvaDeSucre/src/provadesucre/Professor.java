package provadesucre;

public class Professor {

}
