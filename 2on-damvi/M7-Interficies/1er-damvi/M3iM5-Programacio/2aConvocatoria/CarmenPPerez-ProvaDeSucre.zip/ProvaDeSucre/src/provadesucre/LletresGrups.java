package provadesucre;

public enum LletresGrups {
	A, B, C
}
