package provadesucre;

public class Main {

	public static void main(String[] args) {
		Persona p1 = new Persona();
		p1.toString();
		Persona p2 = new Persona();
		p2.toString();
		Persona p3 = new Persona();
		p3.toString();
		
		Grup g1 = new Grup(LletresGrups.B, 15);
		g1.toString();
		
		
	}

}
