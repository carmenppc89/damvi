# GITLAB DE DAMVI

## Introducció

Hola estimats alumnes. Teniu una carpeta per a cada UF. Dintre de cada carpeta hi haurà projectes d'Eclipse que es poden importar directament des del client git d'Eclipse

Podeu consultar una guia de git desde el [següent enllaç](https://docs.google.com/document/d/1JthynfEQFJL3rBVygwb60CFIOK7CuIXABoGliIhN534/edit)