package IntroFuncions;

public class Angelv2 {
	
	String nom = "Angel";
	int nPatos = 0;
	float diners = 0;
	int peus = 2;
	
	public void robarPato() {
		System.out.println(nom+" ha robado un pato!");
		nPatos++;
	}
	
	public float venderPato() {
		if(nPatos>0) {
			System.out.println(nom+" ha vendido un pato por 3 dineros");
			diners = diners+3;
			nPatos--;
			return diners;
		}else {
			System.out.println("Angel no tiene pato  (muec muec) ");
			return diners;
		}
	}
	
	public void robarPatoAAngel(Angelv2 otroAngel) {
		if(otroAngel.nPatos>0) {
			System.out.println(nom+" ha robato un pato a "+otroAngel.nom);
			nPatos++;
			otroAngel.nPatos--;
		}
		else {
			System.out.println("Le estas intentando robar a un muerto de hambre");
		}
	}

}
