package TopDown;

public class PatataCaliente {
	
	
	//s'agafa un numero aleatoriamente entre 0 i 1000
	//l'altre diu numeros i se'l respon "SI", "MES GRAN" o "MES PETIT"
	//te 10 intents per encertar el numero.
	
	
	public static void main(String[] args) {
		
	}

}
