package Patemon;

public class Patemon {
	
	public static void main(String[] args) {
		
		Entrenador angel = new Entrenador();
		Entrenador luis = new Entrenador();
		
		angel.pato = new Pato();
		luis.pato = new Pato(25,5,3,Genere.FEMELLA);
		
		combat(angel,luis);
		
	}

	private static void combat(Entrenador angel, Entrenador luis) {
		
		boolean sortir = false;
		
		while(!sortir) {
			
			System.out.println("ataca angel");
			angel.pato.atacar(luis.pato);
			if(luis.pato.hp<=0) {
				sortir=true;
			}
			System.out.println("ataca luis");
			luis.pato.atacar(angel.pato);
			if(angel.pato.hp<=0) {
				sortir=true;
			}
		}
		
		if(luis.pato.hp<=0) {
			System.out.println("Angel ha ganado");
			float dineroPerdido = luis.dineros/2;
			luis.dineros -= dineroPerdido;
			angel.dineros += dineroPerdido;
		}else {
			System.out.println("Luis ha ganado");
			float dineroPerdido = angel.dineros/2;
			angel.dineros -= dineroPerdido;
			luis.dineros += dineroPerdido;
		}
		
		
		
	}

}
