package Patemon;

import java.util.Random;

enum Genere{
	MASCLE,
	FEMELLA,
	NOBINARI
}

public class Pato {
	
	
	int hp;
	int hpmax;
	int atk;
	int def;
	Genere juli;
	
	//Constructor. Funcio especial que serveix per crear objectes d'aquesta classe
	//public Nom de la Classe()
	public Pato() {
		Random r = new Random();
		//numero entre 10 i 100
		hpmax = r.nextInt(90)+10;
		hp=hpmax;
		atk = r.nextInt(9)+1;
		def = r.nextInt(5)+1;
		juli = Genere.MASCLE;
		
	}
	
	public Pato(int hp2, int atk2, int def2, Genere g2) {
		hp = hp2;
		atk = atk2;
		def = def2;
		juli = g2;
	}
	
	public int atacar(Pato otroPato){
		
		Random r = new Random();
		
		
		int dany = (int) (r.nextFloat()*atk - r.nextFloat()*otroPato.def);
		if(dany<0) {
			dany=0;
		}
		System.out.println("pato fa "+dany+" punts de dany al altre pato");

		otroPato.hp= otroPato.hp-dany;
		
		System.out.println("li queden "+otroPato.hp+" punts de vida");
		return otroPato.hp;
		
		
	}

}