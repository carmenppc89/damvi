package IntroFuncions;

public class FuncionsIClasses {
	
	public static void main(String[] args) {
		
		Angelv2 angel = new Angelv2();
		Angelv2 angel2 = new Angelv2();
		Angelv2 angel3 = new Angelv2();
		Angelv2 angel4 = new Angelv2();
		Angelv2 angel5 = new Angelv2();
		
		angel2.peus = 3;
		
		System.out.println("angel te "+angel.peus+" peus");
		System.out.println("angel2 te "+angel2.peus+" peus");
		
		
		angel.robarPato();
		System.out.println("angel te "+angel.nPatos+" anecs");
		System.out.println("angel2 te "+angel2.nPatos+" anecs");
		
		float diners = angel.venderPato();
		diners = diners + angel2.venderPato();
		System.out.println("els meus diners son "+diners);
		
		angel2.robarPato();
		angel2.robarPato();
		angel.robarPatoAAngel(angel2);
		

		System.out.println("angel te "+angel.nPatos+" anecs");
		System.out.println("angel2 te "+angel2.nPatos+" anecs");
		
	}

}
