package Patemon;

public class Entrenador {
	
	String nom;
	Pato pato = new Pato();
	float dineros;
	

}
