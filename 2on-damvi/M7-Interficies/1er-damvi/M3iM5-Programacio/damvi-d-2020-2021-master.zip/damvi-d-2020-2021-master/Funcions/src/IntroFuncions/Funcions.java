package IntroFuncions;

/**
 * Intro a funcions
 * 12/01/21
 * @author marc
 *
 */
public class Funcions {

	
	public static void main(String[] args) {
		
		//una funcio es un tros de codi que pots cridar desde altres llocs
		diuHola();
		System.out.println("albertito");
		diuHola();
		saludar("juli tapate un poco joder");
		//per entrar varies coses li passes separat per coma
		saludar("gerard","marta");
		int res = sumar(4,5);
		System.out.println("el resultat es "+res);
		
		
	}

	private static void saludar(String nom1, String nom2) {
		System.out.println("jaja "+nom1+" i "+nom2+" son nobios"); 
		
	}
	
	//els noms de les variables son locals a la funcio
	public static int sumar(int a, int b) {
		int c = a+b;
		//return, el valor que devuelve
		return c;
		//return a+b; tambe es valid
	}

	//Declaracio de Funcio
	//accesibilitat (public/private/ ) [static] retorn nom( tipusParametre nomParametre, etc){
	public static void diuHola() {
		System.out.println("hola");
	}
	
	public static void saludar(String nom) {
		System.out.println("hola, "+nom);
	}

}
