package TopDown;

public class MasterMind {
	
	//mastermind
	//un jugador tria una combinacio secreta (4 numeros diferents)
	//l'altre intenta endevinarla
	//per cada intent et diu X o O si el numero esta en la posicio correcta o incorrecta
	/* p ex
	 * 
	 * combinacio secreta es 1234
	 * 
	 * 1 2 5 8 -> XX
	 * 5 8 1 2 -> OO
	 * 1 8 4 9 -> XO
	 * 
	 */

}
