package TopDown;

import java.util.Scanner;

public class TresEnRaya {
	
	public static void main(String[] args) {
		
		//variables
		int[][] taulell = new int[3][3];
		int guanyat = 0;
		boolean torn = false;
		Scanner sc = new Scanner(System.in);
		
		
		//bucle principal
		while(guanyat==0) {
			
			
			//separar un 3 en raya per passos
			//demanar fila i columna
			int f = sc.nextInt();
			int c = sc.nextInt();
			taulell=colocarFitxa(f,c,torn,taulell);
			guanyat=comprovarLinia(taulell);
			torn=passarTorn(torn);
			
			
		}
		
		
		
		
		
		
		
		
	}

	private static boolean passarTorn(boolean torn) {
		// TODO Auto-generated method stub
		return false;
	}

	private static int comprovarLinia(int[][] taulell) {
		// TODO Auto-generated method stub
		return 0;
	}

	private static int[][] colocarFitxa(int f, int c, boolean torn, int[][] taulell) {
		// TODO Auto-generated method stub
		return null;
	}

}
