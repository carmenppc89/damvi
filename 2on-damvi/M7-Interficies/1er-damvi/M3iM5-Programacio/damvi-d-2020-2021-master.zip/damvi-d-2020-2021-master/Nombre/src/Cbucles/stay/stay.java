package Cbucles.stay;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

//hola, soc un comentari 
public class stay {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		int felicitat = 5;
		//estat de la maquina d'estats
		int estat = 1;

		// instancies un nou calendar amb data del moment en crear
		Calendar c = new GregorianCalendar();
		// calendar, representacio d'una data
		System.out.println(c.get(Calendar.HOUR_OF_DAY) + " " + c.get(Calendar.MINUTE) + " " + c.get(Calendar.SECOND));

		System.out.println("MENU");

		System.out.println("1 - JUGAR");
		System.out.println("2 - OPTIONS");
		System.out.println("3 - QUIT");

		boolean sortir = false;
		
		while (sortir == false) {
			String resposta = sc.nextLine();

			switch (resposta) {
			case "1":
				boolean suicidi = false;
				while(suicidi == false && ( estat==1 || estat==2) ) {
					LocalDateTime ultimaResposta = LocalDateTime.now();
					String s="";
					if(estat==1) {
						System.out.println("Estic buscant coses! On busco?");
						s = sc.nextLine();	
					}else if (estat == 2) {
						System.out.println("Tinc una clau? On la faig servir?");
						s= sc.nextLine();
					}
					
					
					
					LocalDateTime momentResposta = LocalDateTime.now();
					long segons = ultimaResposta.until(momentResposta, ChronoUnit.SECONDS);
					
					System.out.println(segons);
					if(segons>10) {
						System.out.println("Has trigat en contestarme");
						felicitat --;
					}
					
					if(estat==1) {
						if(s.equals("Basura")) {
							System.out.println("HE TROBAT UNA CLAU");
							estat = 2;
						}
						else {
							System.out.println("NOMES HE TROBAT LA TEVA DIGNITAT");
						}
					}else if(estat==2) {
						if(s.equals("Porta")) {
							System.out.println("HE OBERT LA PORTA. ME'N VAIG");
							estat = 3;
						}else if(s.equals("Basura")) {
							System.out.println("He tirat la clau a la Basura");
							estat = 1;
						}else {
							System.out.println("La clau no entra aqui");
						}
						
					}
					
					
					if(felicitat<=0) {
						System.out.println("Pos me suicido");
						suicidi = true;
					}
				}
				
			case "2":
				System.out.println("No hi ha opcions");
				break;
			case "3":
				sortir = true;
				break;
			}
		}

	}

}
