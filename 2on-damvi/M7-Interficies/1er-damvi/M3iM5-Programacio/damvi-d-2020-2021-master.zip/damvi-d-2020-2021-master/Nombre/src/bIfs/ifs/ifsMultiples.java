package bIfs.ifs;
import java.util.Scanner;

public class ifsMultiples {
	/**
	 * intro ifs-else 25/9/20
	 * @param args
	 */
	public static void main(String[] args) {
		
		//si algu te menys de 20 anys es tiktoker
		//si te mes de 20 i menys de 30 es jove
		//si te mes de 30 i menys de 52 es adult
		//si te 52 o mes es boomer
		
		Scanner sc = new Scanner(System.in);
		int edat = sc.nextInt();
		//esto es una puta mierda de java que llevo 5 a�os pidiendo que lo areglen y dicen que no es un bug pero desde luego que lo es.
		sc.nextLine();
		
		if(edat < 20) {
			System.out.println("Tiktoker");
		}else if(edat >= 20 && edat < 30) {
			System.out.println("Jove");
		}else if(edat>= 30 && edat <52) {
			System.out.println("Adult");
		}else {
			System.out.println("Boomer");
		}
		
		
		String nomProfe = sc.nextLine();
		
		//si vols comparar Strings
		if(nomProfe.equals("Marc")) {
			System.out.println("Programaci�");
		}else if(nomProfe.equals("Dani")) {
			System.out.println("Sistemas");
		}else if(nomProfe.equals("H�ctor")) {
			System.out.println("Game Design");
		}else if(nomProfe.equals("Gregorio")) {
			System.out.println("Ja ja");
		}else if(nomProfe.equals("Eloi")) {
			System.out.println("Llenguatge de Marques");
		}else if(nomProfe.equals("Rosa")) {
			System.out.println("FOL");
		}else {
			System.out.println("�s EL MITIC SUBSTITUT DEL GREGORIO.\\\\n HA ARRIBAT.\n GLORIA!");
		}
		
		
	}

}
