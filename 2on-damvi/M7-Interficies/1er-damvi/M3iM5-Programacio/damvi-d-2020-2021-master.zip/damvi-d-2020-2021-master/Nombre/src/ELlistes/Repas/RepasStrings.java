package ELlistes.Repas;

public class RepasStrings {
	
	public static void main(String[] args) {
		
		String s = "hola que tal supremacia racial";
		
		//substring. Em dona la subString que va de la posicio primera a la segona
		String substring = s.substring(3, 10);
		System.out.println("La substring es "+substring);
		
		//replace
		String reemplas = s.replace("a", "ñ");
		System.out.println(reemplas);
		System.out.println(s);
		String al = "Aladdin";
		String any = al.replace("l", "��");
		any = any.replace("dd", "��");
		System.out.println(any);
		
		
		//split. Converteix una string en un array de strings, tallades per un delimitador
		String[] split = s.split(" ");
		for (int i = 0; i < split.length; i++) {
			System.out.println(split[i]);
		}
		
		String[] split2 = any.split("ñ");
		for (int i = 0; i < split2.length; i++) {
			System.out.println(split2[i]);
		}
		
		
	
		
		
	}

}
