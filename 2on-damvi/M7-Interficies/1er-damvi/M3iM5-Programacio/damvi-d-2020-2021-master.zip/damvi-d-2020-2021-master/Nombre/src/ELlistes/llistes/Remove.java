package ELlistes.llistes;

import java.util.ArrayList;

public class Remove {
	
	public static void main(String[] args) {
		
		String[] array = {"A","B","C","D","E"};
		ArrayList<String> llista = new ArrayList<String>();
		llista.add("A");
		llista.add("B");
		llista.add("C");
		llista.add("D");
		llista.add("Ehola Marcuwu");
		
		llista.remove("D");
		System.out.println(llista);
		
		
	}

}
