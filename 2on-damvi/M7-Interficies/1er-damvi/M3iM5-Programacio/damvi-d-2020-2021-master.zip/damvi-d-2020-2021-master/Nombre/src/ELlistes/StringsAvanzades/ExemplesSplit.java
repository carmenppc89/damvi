package ELlistes.StringsAvanzades;

import java.util.Scanner;

public class ExemplesSplit {
	
	//Exercici Raid del JODER
	//https://joder.ga/problem/raid
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int ncasos = sc.nextInt();
		sc.nextLine();
		for (int cas = 0; cas < ncasos; cas++) {
			String s = sc.nextLine();
			
			//22:30 -> split[0] = 22 ; split[1] = 30
			String[] split = s.split(":");
			String hora = split[0];
			String minut = split[1];
			//passar una String a enter
			int horaint = Integer.parseInt(hora);
			int minutint = Integer.parseInt(minut);
			
			//LA RESTA FEUHO VOSALTRES QUE NO US VULL DONAR PUNTS GRATIS
			
		}
		
		
		
	}

}
