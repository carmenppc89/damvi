package bIfs.ifs;
import java.util.Scanner;

/**
 * Exemples d'exercicis d'ifs:
 * Exercici per fer a casa i entregar per moodle
 * 5/10/20
 * @author IES SABADELL
 *
 */
public class exemplesIF2 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		/*
		 * La nota final es la millor nota entre 25% p1 25% p2 i 50% exfinal o 100% exfinal
		 * L'examen final sempre ha de tenir un minim de 4
		 * Si un dels dos parcials est� per sota de 3 obligatoriament la nota ha de ser per la via d'examen final
		 * 
		 */
		
		double parcial1 = sc.nextDouble();
		double parcial2 = sc.nextDouble();
		double exfinal = sc.nextDouble();
		
		
		
	}

}
