package FMatrius.matrius;

import java.util.Scanner;

public class Quadrat {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int F = sc.nextInt();
		int C = sc.nextInt();
		
		String[][] mat = new String[F][C];
		
		int files = mat.length;
		int columnes = mat[0].length;
		
		for (int i = 0; i < files; i++) {
			for (int j = 0; j < columnes; j++) {
				mat[i][j]=".";
			}
		}
		
		int f1 = sc.nextInt();
		int c1 = sc.nextInt();
		int f2 = sc.nextInt();
		int c2 = sc.nextInt();
		
		
		for (int i = f1; i <= f2; i++) {
			for (int j = c1; j <= c2; j++) {
				mat[i][j]="X";
			}
		}
		
		for (int i = 0; i < files; i++) {
			for (int j = 0; j < columnes; j++) {
				System.out.print(mat[i][j]+" ");
			}System.out.println();
		}
		
		
		
		
		
	}

}
