package Cbucles.exercicisBucles;

/**
 * Exercicis de Bucles de pintar triangle. A fer per els alumnes i entregar per JOEL
 * 21/10/20
 * @author marc
 *
 */
public class PintarTriangle {
	
	public static void main(String[] args) {
		
		int n = 5;
		
		//QUANTS BUCLES? 2
		//FOR I FOR
		//NECESSITEM COMPTADOR? SI
		//NECESSITEM ACUMULADOR? SI - STRING
		
		
	}

}
