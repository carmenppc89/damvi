package bIfs.repasifs;

public class OrsiAnds {
	
	public static void main(String[] args) {
		
		
		
		//  && AND
		
		//  || OR
	}

}
