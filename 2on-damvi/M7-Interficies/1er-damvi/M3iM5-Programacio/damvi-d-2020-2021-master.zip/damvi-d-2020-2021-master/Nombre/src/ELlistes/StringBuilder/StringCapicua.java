package ELlistes.StringBuilder;

import java.util.Scanner;

public class StringCapicua {
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		StringBuilder sb = new StringBuilder(sc.nextLine());
		String s = sc.nextLine();
		
		sb.reverse();
		
		s = s.replace(" ", "");
		
		String s2 = sb.toString().replace(" ", "");
		
		System.out.println(s);
		System.out.println(s2);
		
		if(s.equals(s2)) {
			System.out.println("SI");
		}else {
			System.out.println("NO");
		}
	}

}
