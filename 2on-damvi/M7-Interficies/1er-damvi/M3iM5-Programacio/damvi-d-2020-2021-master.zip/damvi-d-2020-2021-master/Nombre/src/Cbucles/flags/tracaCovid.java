package Cbucles.flags;

import java.util.Scanner;

/**
 * esquema de com fer el problema del JODER Tra�acovid 27/10/20
 * 
 * @author IES SABADELL
 *
 */
public class tracaCovid {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int ncasos = sc.nextInt();
		for (int cas = 0; cas < ncasos; cas++) {
			// legir un numero
			// fer un for de 0 -> numero
			// dintre el for
			// llegeix numero
			// es mes gran que 300? -> activem flag
			// surts del for
			// mires el flag
			// esta activat el flag? -> ALARMA
			// no? -> OK
		}

	}
}
