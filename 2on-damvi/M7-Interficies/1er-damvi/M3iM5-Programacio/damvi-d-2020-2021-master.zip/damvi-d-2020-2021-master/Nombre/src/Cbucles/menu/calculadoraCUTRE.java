package Cbucles.menu;

import java.util.Scanner;

public class calculadoraCUTRE {
	
	public static void main(String[] args) {
		
		//el scanner sempre poseuho com a primera linea
		Scanner sc = new Scanner(System.in);
		
		//fixeuvos que comptadors acumuladors i flags sempre es declraran FORA del bucle a on el vols fer servir
		boolean sortir = false;
		
		

		
		do {
			
			//print amb instruccions. fora o dintre del bucle?
			System.out.println("posa + per sumar - per restar * per multiplicar i / per dividir. q per marxar");
			
			//ha d'estar dintre del bucle
			String comanda = sc.nextLine();
			
			switch(comanda) {
			case "+":
				System.out.println("digues dos nombres");
				int a = sc.nextInt();
				int b = sc.nextInt();
				sc.nextLine();
				int res = a+b;
				System.out.println("El resultat es "+res);
				break;
			case "-":
				System.out.println("digues dos nombres");
				a = sc.nextInt();
				b = sc.nextInt();
				sc.nextLine();
				res = a-b;
				System.out.println("El resultat es "+res);
				break;
			case "*":
				System.out.println("digues dos nombres");
				a = sc.nextInt();
				b = sc.nextInt();
				sc.nextLine();
				res = a*b;
				System.out.println("El resultat es "+res);
				break;
			case "/":
				System.out.println("digues dos nombres");
				a = sc.nextInt();
				b = sc.nextInt();
				sc.nextLine();
				res = a/b;
				System.out.println("El resultat es "+res);
				break;
			case "q":
				System.out.println("bye");
				sortir = true;
				break;
			default:
				System.out.println("error digues una altra cosa");
					
			}
			
			
			
			
			
		}while(sortir==false);
		
		
		
	}

}
