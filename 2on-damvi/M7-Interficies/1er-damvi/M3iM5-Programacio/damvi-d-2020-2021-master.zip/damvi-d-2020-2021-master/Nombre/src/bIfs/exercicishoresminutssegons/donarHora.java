package bIfs.exercicishoresminutssegons;

import java.util.Scanner;

/**
 * Proposta d'exercici em doa l'hora, a on has de verificar que l'hora es correcta i despr�s dir quant queda fins al final de dia
 * 2/10/20
 * @author IES SABADELL
 *
 */
public class donarHora {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int h = sc.nextInt();
		int m = sc.nextInt();
		
		int minutsDunDia=1440;
		
		if(h>23||h<0||m>59||m<0) {
			System.out.println("NO");
		}else {
			//AQUI FAS EL CODI
		}
		
		if(h>=0&&h<24&&m>=0&&m<60) {
			//AQUI FAS EL CODI
		}else {
			System.out.println("NO");
		}
	} 
	

}
