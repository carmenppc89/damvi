/**
 * 
 */
package UtilsEduard;



/**
 * @author EDUARD MONZONIS HIERRO
 * 
 */
public class TestTeclado {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Terminal.write("Com et dius ?: ");
		String nombre = Terminal.readln();
		Terminal.writeln("=====================");
		Terminal.writeln("Hola ------>  "+ nombre);
		Terminal.writeln("=====================");
		Terminal.writeln(" Si ets professor escriu si sino escriu no ");
		int eres = Terminal.getInt();
		if (eres == 1)	{
			Terminal.writeln(" Ets Professor de quin Institut?");
			String entitat =Terminal.readln();
			Terminal.writeln("En el Institut  "+ entitat);
			Terminal.writeln(" Ets Professor de quina assignatura?");
			String assignatura =Terminal.readln();
			Terminal.writeln("Assignatura  "+ assignatura);
			Terminal.writeln("=====================");
			
        }else {
        	if(eres == 2) {
        	Terminal.writeln(" Ets Alumna de quin Institut?");
    		String entitat =Terminal.readln();
    		Terminal.writeln("En el Institut  "+ entitat);
        	Terminal.writeln("=====================");
    		Terminal.writeln(" Ets Alunma de quin curs?");
    		String assignatura =Terminal.readln();
    		Terminal.writeln("Curs  "+ assignatura);
    		Terminal.writeln("=====================");
        	}
        
        }
		
		
	}

}
