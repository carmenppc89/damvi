package Darrays.arrays;

public class Angel {
	
	int neuronas;
	double dineros;
	boolean pareja = false;

}
