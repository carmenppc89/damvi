package Cbucles.exercicisBucles;

import java.util.Scanner;

/**
 * Solcio exercici JOEL president patata
 * 21/10/20
 * @author marc
 *
 */
public class PresidentPatata {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int ncasos = sc.nextInt();
		for (int cas = 0; cas < ncasos; cas++) {
			
			//EXERCICI
			int vegades = sc.nextInt();
			for (int i = 0; i < vegades; i++) {
				System.out.println("No ofendre al president patata");
			}
			System.out.println();
			
			
		}
		
		
	}

}
