/*
 * Creado el 01-abr-2005
 * @date
 * 
 */


/**

 * 
 */
package UtilsEduard;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * @author EDUARD MONZONIS
 * @version 2.0 beta
 * CAPA DE SISTEMA
 * Classe per entrar dades per teclat
 */
public class Terminal {
	/**
	 * Buffer de lectura de teclat
	 */
	private static BufferedReader teclat = new BufferedReader(new InputStreamReader(System.in));
	
	/**
	 * Retorna el que s'ha teclejat sense el CR
	 * @return String
	 */
	public static String readln(){
		try{
			return teclat.readLine();
		} catch(IOException e) {
			//System.out.println(e.toString());
			//e.printStackTrace();
		}
		return "";
	}
	
	/**
	 * Escriu el par�metre a la consola amb CR
	 * @param s : String
	 */
	public static void writeln(String s){
		System.out.println(s);
	}

	/**
	 * Escriu la sortida a la consola amb CR
	 */
	public static void writeln(){
		System.out.println();
	}
	
	/**
	 * Escriu la sortida a la consola sense CR
	 * @param s : String
	 */
	public static void write(String s){
		System.out.print(s);
	}
	
	/**
	 * Pinta el literal y devuelve el String tecleado
	 * @param s es el literal
	 * @return
	 */
	public static String readln(String s){
		write(s + " : ");
		return readln();
	}
	
	/**
	 * Devuelve el entero tecleado
	 * @return
	 */
	public static int getInt(){
		return Integer.parseInt(readln());
	}
	
	/**
	 * Devuelve el real tecleado
	 * @return
	 */
	public static double getDouble(){
		return Double.parseDouble(readln());
	}
	
	/**
	 * Devuelve el String tecleado
	 * @return
	 */
	public static String getString(){
		return readln();
	}

    /**
     * Pinta el literal y devuelve el entero tecleado
     * @param literal
     * @return
     */
	public static int getInt(String literal){
		return Integer.parseInt(readln(literal));
	}
	
	/**
	 * Pinta el literal y devuelve el real tecleado
	 * @param literal
	 * @return
	 */
	public static double getDouble(String literal){
		return Double.parseDouble(readln(literal));
	}
	
	/**
	 * Pinta el literal y devuelve el String tecleado
	 * @param literal
	 * @return
	 */
	public static String getString(String literal){
		return readln(literal);
	}

	 public static String readln1(boolean bol) {
	        
	        boolean bolt;
	        bolt = false;
	        System.out.println("La variable x es: " + bolt);
	        
	        bolt = true;
	        System.out.println("La variable x es: " + bolt);
	        
	        if (bolt == true) {
	            System.out.println("La variable x existe");
	        }
			return null;
	    }
	    
	}
	

