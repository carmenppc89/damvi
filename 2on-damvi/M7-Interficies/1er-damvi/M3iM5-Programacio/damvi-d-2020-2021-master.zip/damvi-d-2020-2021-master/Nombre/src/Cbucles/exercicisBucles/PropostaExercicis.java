package Cbucles.exercicisBucles;

/**
 * Proposta d'exercicis de bucles a entregar per JOEL
 * 21/10/20
 * @author marc
 *
 */
public class PropostaExercicis {
	
	public static void main(String[] args) {
		
		
		//3 IGUALES PARA HOY
		// https://joder.ga/problem/tresiguales
		
		//SUMAR VECTORS PER POSICIO
		//https://joder.ga/problem/vectors1
		
		//CALCULAR DIVISORS
		//https://joder.ga/problem/divisors
		//
		
		
	}

}
