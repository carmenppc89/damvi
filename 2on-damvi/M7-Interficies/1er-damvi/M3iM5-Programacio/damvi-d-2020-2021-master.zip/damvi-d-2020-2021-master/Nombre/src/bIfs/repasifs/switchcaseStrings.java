package bIfs.repasifs;

import java.util.Scanner;

public class switchcaseStrings {
	
	
	
	//EL BARRET ET RPEGUNTA. QUE ES LO MES IMPORTANT PER TU?
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String important = sc.nextLine();
		
		switch(important) {
		
		case "Soc Harry Potter":
			System.out.println("Oh ets molt important i influent. Que guay.");
			//el switch va recorrent i va fent tot el que dius fins que troba un break.
		case "Valentia":
		case "Coratge":
			System.out.println("Gryffindor");
			break;
		case "Inteligencia":
			System.out.println("Ravenclaw");
			break;
		case "Ambici�":
			System.out.println("Slytherin");
			break;
		default:
			System.out.println("Hufflepuff");
			//al default no cal break perque es l'ultim
		}
		
	}
	
	

}
