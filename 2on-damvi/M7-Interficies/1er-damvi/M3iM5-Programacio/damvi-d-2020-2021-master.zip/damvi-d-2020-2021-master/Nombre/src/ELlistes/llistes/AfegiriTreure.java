package ELlistes.llistes;

import java.util.ArrayList;
import java.util.Random;

public class AfegiriTreure {
	
	public static void main(String[] args) {
		
int array[] = new int[5];
		
		//ArrayList<Tipus> nom = new ArrayList<>();
		ArrayList<Integer> llista = new ArrayList<>();
		
		//omplir un array vs omplir una llista
		Random r = new Random();
		
		for (int i = 0; i < array.length; i++) {
			array[i]=r.nextInt(10);
		}
		
		for (int i = 0; i < 5; i++) {
			int numeroRandom = r.nextInt(10);
			//afegeix un element al final
			llista.add(numeroRandom);
		}
		System.out.println("Array");
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i]+" ");
		}
		System.out.println();
		System.out.println("Llista");
		System.out.println(llista);
		
		
		
		//borrar la 3a posicio en un array
		for (int i = 4; i < args.length; i++) {
			int element = array[i];
			array[i-1] = element;
		}
		//l'ultima posicio es array.length-1 perque comences desde el 0
		array[array.length-1] = -1;
		
		System.out.println("Array");
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i]+" ");
		}
		System.out.println();
		
		llista.remove(3);
		System.out.println(llista);
		System.out.println(llista.size());
		
		
		
		

		
		
		
	}

}
