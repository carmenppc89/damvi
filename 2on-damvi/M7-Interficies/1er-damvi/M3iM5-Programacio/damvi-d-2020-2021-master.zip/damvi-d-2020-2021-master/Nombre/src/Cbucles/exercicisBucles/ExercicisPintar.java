package Cbucles.exercicisBucles;

/**
 * Exercicis de Bucles de pintar quadrats
 * 21/10/20
 * @author marc
 *
 */
public class ExercicisPintar {
	
	
	//pintar quadrats
	public static void main(String[] args) {
		
		int n = 0;
		
		//pintar una linea.
		
		//bucle? FOR. Sabem inici = 0  final = n;
		//necessitem un comptador? NO
		//necessitem un acumulador? SI - String
		String acc = "";
		for (int i = 0; i < n ; i++) {
			//formula del acumulador es acc = acc + algunacosa
			acc = acc + "X";
		}
		
		System.out.println(acc);
		
		
		
		
		
		
	}

}
