package robots;

import robots.Destructor;

public class Taller extends MarkJava {
	MarkJava[][] robots = new MarkJava[5][5];

	void main(String[] args) {
		creaTaller();
	}

	void creaTaller() {
		// TODO Auto-generated method stub
		Taller taller;
		taller = new Taller();

		for (int i = 0; i < 10; i++) {
			torn();
		}
	}

	void torn() {
		// TODO Auto-generated method stub

		for (int f = 0; f < 5; f++) {
			for (int c = 0; c < 5; c++) {
				if (robots[f][c] instanceof Destructor) {

					if (Destructor.decideixSiMou()) {
						resolMoviment(this, f, c);
					}

				} else if (robots[f][c] instanceof Mecanic) {

				} else if (robots[f][c] instanceof Replicant) {

				} else {
					// nothing
				}
			}
		}

		// resetejar haMougut=false

		mostraTaller();
	}

	void resolMoviment(MarkJava robotAMoure, int f, int c) {
		int opcio = random.nextInt(4);

		if (opcio == 0 && f + 1 <= 5) {
			f++;
			this.energia--;
		} else if (opcio == 1 && c + 1 <= 5) {
			c++;
			this.energia--;
		} else if (opcio == 2 && f - 1 >= 0) {
			f--;
			this.energia--;
		} else if (opcio == 3 && c - 1 >= 0) {
			c--;
			this.energia--;
		} else {
			// nothing
		}

		
		
	}

	void mostraTaller() {

		for (int f = 0; f < 5; f++) {
			System.out.println();
			for (int c = 0; c < 5; c++) {
				if (robots[f][c] instanceof Destructor) {
					System.out.print("D ");
				} else if (robots[f][c] instanceof Mecanic) {
					System.out.print("M ");
				} else if (robots[f][c] instanceof Replicant) {
					System.out.print("R ");
				} else {
					System.out.print("_ ");
				}

			}
		}
		System.out.println();
	}
}
