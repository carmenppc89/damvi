package robots;

public class Mecanic extends MarkJava{

	@Override
	void interactua(MarkJava unAltreRobot) {
		if(this.energia>4) {
			unAltreRobot.recarregaBateria();
			this.energia=-1;
		}
	}
	
	@Override
	boolean decideixSiMou(){
		if(this.energia<5) {
			this.recarregaBateria();
			return false;
		}else if(this.haMogut==false&&this.energia>=5) {
			if(random.nextInt(11)+1<=6) {
				this.haMogut=true;
				return true;
			}else {
				return false;
			}
		}else {
			return false;
		}
	}
	
}
