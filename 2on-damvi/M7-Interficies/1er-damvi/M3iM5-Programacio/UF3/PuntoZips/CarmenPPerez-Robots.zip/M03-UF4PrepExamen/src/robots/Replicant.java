package robots;

public class Replicant extends MarkJava {

	MarkJava robotQueReplica;

	@Override
	void interactua(MarkJava unAltreRobot) {
		robotQueReplica = unAltreRobot;
	}

	@Override
	boolean decideixSiMou() {

		if (this.haMogut == true) {
			return false;
		} else {
			if (this.energia < 7) {
				return false;
			} else {
				if ((random.nextInt(11) + 1) <= 6) {
					this.haMogut = true;
					return true;
				} else {
					return false;
				}
			}
		}

	}

	MarkJava construeix() {
		if (this.energia < 7) {
			return null;
		} else {
			if (robotQueReplica == null) {
				switch (random.nextInt(2)) {
				case 0:
					this.energia = -5;
					MarkJava Destructor = new MarkJava();
					return Destructor;

				case 1:
					this.energia = -5;
					MarkJava Mecanic = new MarkJava();
					return Mecanic;

				case 2:
					this.energia = -5;
					MarkJava Replicant = new MarkJava();
					return Replicant;

				default:
					return null;

				}
			} else {
				this.energia = -5;
				return robotQueReplica;
			}
		}
	}

}
