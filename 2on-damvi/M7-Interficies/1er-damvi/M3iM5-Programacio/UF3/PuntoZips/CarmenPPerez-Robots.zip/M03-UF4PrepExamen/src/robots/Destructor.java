package robots;

public class Destructor extends MarkJava {

	@Override
	void interactua(MarkJava unAltreRobot) {
		if (this.energia < 5) {
			// System.out.println("Energia insuficient("+this.energia+")");
			return;
		} else {
			if (unAltreRobot instanceof Destructor) {
				if ((random.nextInt(1)) == 1) {
					unAltreRobot.gastaBateria();
					this.energia = -3;
				} else {
					// System.out.println("Latac ha fallat");
					return;
				}
			} else {
				unAltreRobot.gastaBateria();
				this.energia = -3;
			}
		}
	}

	@Override
	boolean decideixSiMou() {
		if (this.energia < 5) {
			return false;
		} else {
			if (this.haMogut == true) {
				return false;
			} else {
				if ((random.nextInt(11) + 1) <= 4) {
					this.haMogut = true;
					return true;
				} else {
					return false;
				}
			}

		}

	}
}
