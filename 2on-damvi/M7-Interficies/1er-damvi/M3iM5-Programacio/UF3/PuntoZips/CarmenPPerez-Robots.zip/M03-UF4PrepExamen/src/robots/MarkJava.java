package robots;

import java.util.Random;

public class MarkJava {
	Random random;
	int energia = 10;
	boolean haMogut;
	
	

	int obteEnergia() {
		System.out.println("Energia: " + this.energia);
		return this.energia;
	}

	boolean decideixSiMou() {
		if (this.haMogut == true) {
			this.haMogut=false;
			return false;
		} else {
			this.haMogut=true;
			return true;
		}
	}

	void gastaEnergia(int energiaGastada) {
		this.energia = this.energia - energiaGastada;
		if (this.energia < 0)
			this.energia = 0;
	}

	void gastaBateria() {
		this.energia = 0;
	}

	void interactua(MarkJava unAltreRobot) {
		// defineix que pasa quan robot troba un altre
	}
	
	void recarregaBateria() {
		this.energia=10;
	}
}
