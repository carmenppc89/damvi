package Contsruct;

import Core.Field;
import Core.PhysicBody;
import Core.Sprite;
import main.Disparable;

public class Projectil extends PhysicBody {
	
	public static int unProj = 0;

	public Projectil(String name, int x1, int y1, int x2, int y2, double angle, String path, Field f) {
		super(name, x1, y1, x2, y2, angle, path, f);
	}

	public Projectil(Projectil p, int x1, int y1, int x2, int y2) {
		super(p.name, x1, y1, x2, y2, p.angle, p.path, p.f);
		p.trigger = true;
	}

	@Override
	public void onCollisionEnter(Sprite sprite) {
		// TODO Auto-generated method stub

		System.out.println("colisiona con " + sprite.name);

		if (sprite instanceof Disparable) {

			Disparable d = (Disparable) sprite;

			d.danyar();

			System.out.println("PUM");
			System.out.println("Projectil borrat");
			unProj=0;

			this.delete();
		}

	}
	

	public void Update() {
		if (this.x1 > 20)
			System.out.println("Projectil borrat");
			unProj=0;
			this.delete();
			
	}

	@Override
	public void onCollisionExit(Sprite sprite) {
		// TODO Auto-generated method stub

	}

	public void movLilBitch() {
		this.setVelocity(100, 0);
		// this.setConstantForce(-1, 0);

	}

	/*
	 * public void moveUp() { this.setVelocity(0, 1); this.setConstantForce(0, -1);
	 * 
	 * }
	 */

}
