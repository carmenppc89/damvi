package main;

import Contsruct.Enemic;
import Contsruct.Personatge;
import Contsruct.Roca;
import Core.Field;
import Core.Window;

public class main {
	static Field f = new Field();
	static Window w = new Window(f);

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Roca Terra = new Roca("Terra", 50, 400, 650, 450, 0, "resources/swap.png", f, 0);
		Roca plataforma = new Roca("plataforma", 750, 300, 1100, 350, 0, "resources/rainb.jpg", f, 0);
		Roca plataforma1 = new Roca("plataforma", 1200, 400, 1500, 450, 0, "resources/rainb.jpg", f, 0);

		Personatge link = new Personatge("link", 50, 350, 100, 400, 0, "resources/link1.gif", f);
		link.flippedX = false;
		link.setConstantForce(0, 0.2);

		Enemic enemic = new Enemic("enemic", 450, 350, 500, 400, 0, "resources/enemigo.gif", f);

		for (;;) {
			f.draw();
			Thread.sleep(30);

			if (w.getKeysDown().contains('w'))
				link.jump();

			if (w.getPressedKeys().contains('a'))
				link.movBitch2(input.ESQUERRA);

			if (w.getPressedKeys().contains('d'))
				link.movBitch2(input.DRETA);

			if (w.getPressedKeys().contains('e'))
				link.disparar();
		}

	}

}
