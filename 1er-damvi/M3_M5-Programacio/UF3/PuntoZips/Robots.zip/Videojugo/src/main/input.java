package main;

public enum input {
	DRETA, ESQUERRA, SALT, DISPARAR
}
