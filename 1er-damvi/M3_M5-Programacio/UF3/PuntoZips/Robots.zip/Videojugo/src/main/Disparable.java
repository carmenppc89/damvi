package main;

public interface Disparable {

	void danyar();

	
	
}
