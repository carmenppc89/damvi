package examen;

import java.util.Scanner;

public class Exercici1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		

		sc.close();
	}

}
